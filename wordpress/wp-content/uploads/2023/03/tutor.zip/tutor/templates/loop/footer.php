<?php
/**
 * @package Tutor\Templates
 * @subpackage CourseLoopPart
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

?>

<div class="tutor-card-footer">
	<?php tutor_course_loop_price(); ?>
</div>
